const express = require("express");
const servidor = express();
const port = 3005;
const os = require("os");

servidor.get("/", (req, res) => {
  res.send(`<center>
    <h1>
    Hola de nuevo mundo ${port} 
    <h2>
    ${os.hostname}
    <h2> 
    <h3>
    ${os.cpus()[0].model}
    <br>
    ${os.freemem}
    <br>
    ${os.tmpdir}
    <br>
    ${os.platform}
    <br>
    ${os.release}
    <br>
    ${os.totalmem}
    <h3>
    <style>
    h1{
        color: gold;
    }
    <style>
    <h1>
    <center> `);
});

servidor.listen(port, () => {
  console.log("Hola de nuevo mundo");
});
const fs = require('fs')
fs.appendFile(`${os.tmpdir}/CHECHO.html`, "GOLEADORRRRRRRR", (error)=>{
    if (error) {
        throw error;
    }
    console.log("Archivo creado");
})
