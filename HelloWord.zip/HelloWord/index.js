//como crear un servidor
const express = require('express')
const servidor = express();
const port = 3001;
//Pregunta y respuesta
servidor.get('/',(requiere,response)=>{
    response.send(`Hola mundo     :)`)
})

//verificar si funcina en consola
servidor.listen(port,()=>{
    console.log('Hola mundo');
})