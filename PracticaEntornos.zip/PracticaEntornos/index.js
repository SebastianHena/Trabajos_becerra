const express = require("express");
const dotenv = require("dotenv");
const colors = require("colors");
const server = express();
dotenv.config();
const puerto = process.env.PUERTO;

server.get('/',(req,res)=>{
    res.send(`<table border>
    <th> Nombre </th>
    <th> Identificacion </th>
    <th> Foto </th>

     <tr>
     <td> ${process.env.NOMBRE}</td>
     <td> ${process.env.ID}</td>
     <td> ${process.env.IMG}</td>
     </tr>

    </table>`)
})
server.listen(puerto, ()=>{
    console.log(`Estoy en el puerto ${puerto}`)
})

